#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "tapa::tapa" for configuration "Release"
set_property(TARGET tapa::tapa APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(tapa::tapa PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libtapa.a"
  )

list(APPEND _IMPORT_CHECK_TARGETS tapa::tapa )
list(APPEND _IMPORT_CHECK_FILES_FOR_tapa::tapa "${_IMPORT_PREFIX}/lib/libtapa.a" )

# Import target "tapa::tapa_shared" for configuration "Release"
set_property(TARGET tapa::tapa_shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(tapa::tapa_shared PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libtapa.so"
  IMPORTED_SONAME_RELEASE "libtapa.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS tapa::tapa_shared )
list(APPEND _IMPORT_CHECK_FILES_FOR_tapa::tapa_shared "${_IMPORT_PREFIX}/lib/libtapa.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
