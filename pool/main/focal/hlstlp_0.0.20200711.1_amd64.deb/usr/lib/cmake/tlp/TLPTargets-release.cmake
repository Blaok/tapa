#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "tlp::tlp" for configuration "Release"
set_property(TARGET tlp::tlp APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(tlp::tlp PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libtlp.a"
  )

list(APPEND _IMPORT_CHECK_TARGETS tlp::tlp )
list(APPEND _IMPORT_CHECK_FILES_FOR_tlp::tlp "${_IMPORT_PREFIX}/lib/libtlp.a" )

# Import target "tlp::tlp_shared" for configuration "Release"
set_property(TARGET tlp::tlp_shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(tlp::tlp_shared PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libtlp.so"
  IMPORTED_SONAME_RELEASE "libtlp.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS tlp::tlp_shared )
list(APPEND _IMPORT_CHECK_FILES_FOR_tlp::tlp_shared "${_IMPORT_PREFIX}/lib/libtlp.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
